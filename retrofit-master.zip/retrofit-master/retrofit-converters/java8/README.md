Java 8 Converter (Deprecated)
=============================

A `Converter` which supports Java 8's `Optional<T>` by delegating to other converters for `T`
and then wrapping it into `Optional`.

This converter is no longer needed. Support for `Optional` is built-in to Retrofit and now works
without configuration.
